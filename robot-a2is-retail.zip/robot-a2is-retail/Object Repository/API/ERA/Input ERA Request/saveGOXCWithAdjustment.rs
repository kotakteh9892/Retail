<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>saveGOXCWithAdjustment</name>
   <tag></tag>
   <elementGuidId>9d1d509e-0fb7-4921-a466-5b7db648099c</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;pRegistrationNo&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.regisNO}&quot;
    },
    {
      &quot;name&quot;: &quot;pValidFrom&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.dateFrom}&quot;
    },
    {
      &quot;name&quot;: &quot;pValidTo&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.dateTo}&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhoneNo&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.phoneNO}&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleCode&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.VehicleCode}&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleYear&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.year}&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleDescription&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.PropertyDesc}&quot;
    },
    {
      &quot;name&quot;: &quot;pIsGOXCGASI&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.status}&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestDate&quot;,
      &quot;value&quot;: &quot;${requestDate}&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestUser&quot;,
      &quot;value&quot;: &quot;${requestUser}&quot;
    },
    {
      &quot;name&quot;: &quot;pPICOnLocation&quot;,
      &quot;value&quot;: &quot;${piconLoc}&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhone1&quot;,
      &quot;value&quot;: &quot;${phone1}&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhone2&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pLocation&quot;,
      &quot;value&quot;: &quot;${Location}&quot;
    },
    {
      &quot;name&quot;: &quot;pLocationLat&quot;,
      &quot;value&quot;: &quot;${Lat}&quot;
    },
    {
      &quot;name&quot;: &quot;pLocationLong&quot;,
      &quot;value&quot;: &quot;${Long}&quot;
    },
    {
      &quot;name&quot;: &quot;pLocationDetail&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pDestination&quot;,
      &quot;value&quot;: &quot;${Destination}&quot;
    },
    {
      &quot;name&quot;: &quot;pDestinationLat&quot;,
      &quot;value&quot;: &quot;${DestLat}&quot;
    },
    {
      &quot;name&quot;: &quot;pDestinationLong&quot;,
      &quot;value&quot;: &quot;${DestLong}&quot;
    },
    {
      &quot;name&quot;: &quot;pDestinationDetail&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestCategoryID&quot;,
      &quot;value&quot;: &quot;${requestCatID}&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestSubCategoryID&quot;,
      &quot;value&quot;: &quot;${requestsubCatID}&quot;
    },
    {
      &quot;name&quot;: &quot;pFloodHeight&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pAccessToTheSite&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pApprovalStatusID&quot;,
      &quot;value&quot;: &quot;${approvalStatID}&quot;
    },
    {
      &quot;name&quot;: &quot;pApprovalLevelID&quot;,
      &quot;value&quot;: &quot;${approvalLevelID}&quot;
    },
    {
      &quot;name&quot;: &quot;pPICApprovalName&quot;,
      &quot;value&quot;: &quot;${approvalName}&quot;
    },
    {
      &quot;name&quot;: &quot;pConfirmationDate&quot;,
      &quot;value&quot;: &quot;${confirmDate}&quot;
    },
    {
      &quot;name&quot;: &quot;pAdjustmentCategory&quot;,
      &quot;value&quot;: &quot;[${AdjustCat}]&quot;
    },
    {
      &quot;name&quot;: &quot;pDescription&quot;,
      &quot;value&quot;: &quot;${Desc}&quot;
    },
    {
      &quot;name&quot;: &quot;pCustomerCategoryID&quot;,
      &quot;value&quot;: &quot;${custCatID}&quot;
    },
    {
      &quot;name&quot;: &quot;pBranchLocationID&quot;,
      &quot;value&quot;: &quot;${branchLocID}&quot;
    },
    {
      &quot;name&quot;: &quot;pChannelID&quot;,
      &quot;value&quot;: &quot;${channelID}&quot;
    },
    {
      &quot;name&quot;: &quot;pName&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.Name}&quot;
    },
    {
      &quot;name&quot;: &quot;pCardNo&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.temp}&quot;
    },
    {
      &quot;name&quot;: &quot;pConfirmationNo&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.refNo}&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${GlobalVariable.authorization}</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/InputERARequest/saveGOXCWithAdjusment</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
