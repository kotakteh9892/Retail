<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>activateGOXC</name>
   <tag></tag>
   <elementGuidId>76cef12f-2870-44a5-b77f-172750c73710</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;pIsGOXCGASI&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.status}&quot;
    },
    {
      &quot;name&quot;: &quot;pProgramID&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.ID}&quot;
    },
    {
      &quot;name&quot;: &quot;pConfirmationNo&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.refNo}&quot;
    },
    {
      &quot;name&quot;: &quot;pCardNo&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.temp}&quot;
    },
    {
      &quot;name&quot;: &quot;pName&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.Name}&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhoneNo1&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.phoneNO}&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhoneNo2&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pRegistrationNo&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.regisNO}&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleBrand&quot;,
      &quot;value&quot;: &quot;B206&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleModel&quot;,
      &quot;value&quot;: &quot;M01899&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleCode&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleYear&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.year}&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleDescription&quot;,
      &quot;value&quot;: &quot;${GlobalVariable.PropertyDesc}&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${GlobalVariable.authorization}</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/InputERARequest/activateGOXC</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
