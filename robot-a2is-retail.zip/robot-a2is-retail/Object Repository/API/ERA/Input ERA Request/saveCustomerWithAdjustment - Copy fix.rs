<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>saveCustomerWithAdjustment - Copy fix</name>
   <tag></tag>
   <elementGuidId>7ca9cf84-f4e6-40ec-a111-8940cc1625a9</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;pRegistrationNo&quot;,
      &quot;value&quot;: &quot;B1242DEW&quot;
    },
    {
      &quot;name&quot;: &quot;pPolicyNo&quot;,
      &quot;value&quot;: &quot;2102493503&quot;
    },
    {
      &quot;name&quot;: &quot;pEndNo&quot;,
      &quot;value&quot;: &quot;0&quot;
    },
    {
      &quot;name&quot;: &quot;pNameOnPolicy&quot;,
      &quot;value&quot;: &quot;SULAIMAN ATL&quot;
    },
    {
      &quot;name&quot;: &quot;pPeriodFrom&quot;,
      &quot;value&quot;: &quot;18/02/2020&quot;
    },
    {
      &quot;name&quot;: &quot;pPeriodTo&quot;,
      &quot;value&quot;: &quot;18/02/2020&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhoneNo&quot;,
      &quot;value&quot;: &quot;+62866666666666&quot;
    },
    {
      &quot;name&quot;: &quot;pProduct&quot;,
      &quot;value&quot;: &quot;GO Digital&quot;
    },
    {
      &quot;name&quot;: &quot;pBusinessSource&quot;,
      &quot;value&quot;: &quot;P3C107-P3C107 - Direct Sales via Online Commerce&quot;
    },
    {
      &quot;name&quot;: &quot;pCoverage&quot;,
      &quot;value&quot;: &quot;ALLRIK 18/02/2020 - 18/02/2021,ETV 18/02/2020 - 18/02/2021,FLD 18/02/2020 - 18/02/2021,SRCC 18/02/2020 - 18/02/2021&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleCode&quot;,
      &quot;value&quot;: &quot;V66698&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleYear&quot;,
      &quot;value&quot;: &quot;2020&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleDescription&quot;,
      &quot;value&quot;: &quot;TOYOTA AVANZA Z&quot;
    },
    {
      &quot;name&quot;: &quot;pARStatus&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pIsRetail&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pChasisNo&quot;,
      &quot;value&quot;: &quot;CSLMGO8&quot;
    },
    {
      &quot;name&quot;: &quot;pEngineNo&quot;,
      &quot;value&quot;: &quot;ESLMGO8&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestDate&quot;,
      &quot;value&quot;: &quot;19/02/2021 10:55:35.939&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestUser&quot;,
      &quot;value&quot;: &quot;${requestUser}&quot;
    },
    {
      &quot;name&quot;: &quot;pPICOnLocation&quot;,
      &quot;value&quot;: &quot;reqa&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhone1&quot;,
      &quot;value&quot;: &quot;reqa&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhone2&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pLocation&quot;,
      &quot;value&quot;: &quot;Jl. TB Simatupang, RT.1/RW.5, Ragunan, Kec. Ps. Minggu, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12550, Indonesia&quot;
    },
    {
      &quot;name&quot;: &quot;pLocationLat&quot;,
      &quot;value&quot;: &quot;-6.2926515&quot;
    },
    {
      &quot;name&quot;: &quot;pLocationLong&quot;,
      &quot;value&quot;: &quot;106.8171689&quot;
    },
    {
      &quot;name&quot;: &quot;pLocationDetail&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pDestination&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pDestinationLat&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pDestinationLong&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pDestinationDetail&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestCategoryID&quot;,
      &quot;value&quot;: &quot;2&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestSubCategoryID&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pFloodHeight&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pAccessToTheSite&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pApprovalStatusID&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pApprovalLevelID&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pPICApprovalName&quot;,
      &quot;value&quot;: &quot;picapp1&quot;
    },
    {
      &quot;name&quot;: &quot;pConfirmationDate&quot;,
      &quot;value&quot;: &quot;19/02/2021 10:56&quot;
    },
    {
      &quot;name&quot;: &quot;pAdjustmentCategory&quot;,
      &quot;value&quot;: &quot;[{\&quot;text\&quot;:\&quot;Policy has expired\&quot;,\&quot;value\&quot;:1}]&quot;
    },
    {
      &quot;name&quot;: &quot;pDescription&quot;,
      &quot;value&quot;: &quot;des&quot;
    },
    {
      &quot;name&quot;: &quot;pCustomerCategoryID&quot;,
      &quot;value&quot;: &quot;0&quot;
    },
    {
      &quot;name&quot;: &quot;pBranchLocationID&quot;,
      &quot;value&quot;: &quot;023&quot;
    },
    {
      &quot;name&quot;: &quot;pChannelID&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pDealerName&quot;,
      &quot;value&quot;: &quot;&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${GlobalVariable.authorization}</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/InputERARequest/saveCustomerWithAdjusment</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
