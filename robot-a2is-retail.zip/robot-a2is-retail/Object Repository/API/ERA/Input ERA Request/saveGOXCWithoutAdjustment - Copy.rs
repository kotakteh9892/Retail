<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>saveGOXCWithoutAdjustment - Copy</name>
   <tag></tag>
   <elementGuidId>f556958d-8d10-4b65-ae40-839b79cb1aae</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;pRegistrationNo&quot;,
      &quot;value&quot;: &quot;B400SSI&quot;
    },
    {
      &quot;name&quot;: &quot;pValidFrom&quot;,
      &quot;value&quot;: &quot;24/02/2021&quot;
    },
    {
      &quot;name&quot;: &quot;pValidTo&quot;,
      &quot;value&quot;: &quot;31/12/2021&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhoneNo&quot;,
      &quot;value&quot;: &quot;08989987283&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleCode&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleYear&quot;,
      &quot;value&quot;: &quot;2016&quot;
    },
    {
      &quot;name&quot;: &quot;pVehicleDescription&quot;,
      &quot;value&quot;: &quot;BAJAJ QUTE&quot;
    },
    {
      &quot;name&quot;: &quot;pIsGOXCGASI&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestDate&quot;,
      &quot;value&quot;: &quot;25/02/2021 10:07:19.351&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestUser&quot;,
      &quot;value&quot;: &quot;asas&quot;
    },
    {
      &quot;name&quot;: &quot;pPICOnLocation&quot;,
      &quot;value&quot;: &quot;asas&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhone1&quot;,
      &quot;value&quot;: &quot;08989987283&quot;
    },
    {
      &quot;name&quot;: &quot;pMobilePhone2&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pLocation&quot;,
      &quot;value&quot;: &quot;Jl. TB Simatupang, RT.1/RW.5, Ragunan, Kec. Ps. Minggu, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12550, Indonesia&quot;
    },
    {
      &quot;name&quot;: &quot;pLocationLat&quot;,
      &quot;value&quot;: &quot;-6.2926515&quot;
    },
    {
      &quot;name&quot;: &quot;pLocationLong&quot;,
      &quot;value&quot;: &quot;106.8171689&quot;
    },
    {
      &quot;name&quot;: &quot;pLocationDetail&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pDestination&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pDestinationLat&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pDestinationLong&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pDestinationDetail&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestCategoryID&quot;,
      &quot;value&quot;: &quot;2&quot;
    },
    {
      &quot;name&quot;: &quot;pRequestSubCategoryID&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pFloodHeight&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pAccessToTheSite&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pCustomerCategoryID&quot;,
      &quot;value&quot;: &quot;0&quot;
    },
    {
      &quot;name&quot;: &quot;pBranchLocationID&quot;,
      &quot;value&quot;: &quot;021&quot;
    },
    {
      &quot;name&quot;: &quot;pChannelID&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pName&quot;,
      &quot;value&quot;: &quot;notAktif_inPeriod&quot;
    },
    {
      &quot;name&quot;: &quot;pCardNo&quot;,
      &quot;value&quot;: &quot;GOX-21QW001C&quot;
    },
    {
      &quot;name&quot;: &quot;pConfirmationNo&quot;,
      &quot;value&quot;: &quot;8596616&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer egQKtaqzOyluxeex+S9n1z//FyBWEU0THZ9ZWLPdsZWElBgvwj1pyZYm4PCdTe9LKekQi6FBjZjoFLDzQdddY+PvZcYzNFNl8wTWh03AGN3LLCgdRTcrssbnmcwrFInt3ERe0hV+jcw1//X9JPIGqPkTeL/rfwGwOXQleQedvgj8L6vDu+7ey3SMUEGgZqvd9d6Z57ydCMY/7/2KIUBstlp7EWwTrtXnYKC6YdnAh9gPCM7onLnItyu85ceRMFbu</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/InputERARequest/saveGOXCWithAdjusment</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
