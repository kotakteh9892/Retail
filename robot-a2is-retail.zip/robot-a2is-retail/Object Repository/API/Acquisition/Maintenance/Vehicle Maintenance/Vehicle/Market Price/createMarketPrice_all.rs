<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>createMarketPrice_all</name>
   <tag></tag>
   <elementGuidId>942ffd39-66b0-4f8c-8c0c-015ae0d9ad2b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;qType&quot;,
      &quot;value&quot;: &quot;Add&quot;
    },
    {
      &quot;name&quot;: &quot;vehicleCode&quot;,
      &quot;value&quot;: &quot;${vehicleCode}&quot;
    },
    {
      &quot;name&quot;: &quot;geoid&quot;,
      &quot;value&quot;: &quot;${geoArea}&quot;
    },
    {
      &quot;name&quot;: &quot;effectivedate&quot;,
      &quot;value&quot;: &quot;${effectiveDate}&quot;
    },
    {
      &quot;name&quot;: &quot;year&quot;,
      &quot;value&quot;: &quot;${year}&quot;
    },
    {
      &quot;name&quot;: &quot;currid&quot;,
      &quot;value&quot;: &quot;${currID}&quot;
    },
    {
      &quot;name&quot;: &quot;price&quot;,
      &quot;value&quot;: &quot;${price}&quot;
    },
    {
      &quot;name&quot;: &quot;mindev&quot;,
      &quot;value&quot;: &quot;${minDev}&quot;
    },
    {
      &quot;name&quot;: &quot;maxdev&quot;,
      &quot;value&quot;: &quot;${maxDev}&quot;
    },
    {
      &quot;name&quot;: &quot;qBrandID&quot;,
      &quot;value&quot;: &quot;${brandID}&quot;
    },
    {
      &quot;name&quot;: &quot;pUpdateToAllArea&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pListAreaCode&quot;,
      &quot;value&quot;: &quot;000001|000002|000004|000007|000008|000009|000010|000011|000012|000013|000014|000015|000016|000017|000018|000019|000020|000021|C00077|&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${authorization}</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/VehicleMaintenance/saveUpdateMarketPrice</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
