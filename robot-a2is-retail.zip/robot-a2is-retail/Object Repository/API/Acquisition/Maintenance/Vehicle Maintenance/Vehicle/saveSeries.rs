<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>saveSeries</name>
   <tag></tag>
   <elementGuidId>f39f7bb1-201d-469f-a137-c2452a667d5e</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>0</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;qType&quot;,
      &quot;value&quot;: &quot;Add&quot;
    },
    {
      &quot;name&quot;: &quot;brandid&quot;,
      &quot;value&quot;: &quot;${brandID}&quot;
    },
    {
      &quot;name&quot;: &quot;modelid&quot;,
      &quot;value&quot;: &quot;${modelID}&quot;
    },
    {
      &quot;name&quot;: &quot;vehicleType&quot;,
      &quot;value&quot;: &quot;${vehicleType}&quot;
    },
    {
      &quot;name&quot;: &quot;vehicleCode&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;description&quot;,
      &quot;value&quot;: &quot;${description}&quot;
    },
    {
      &quot;name&quot;: &quot;fuel&quot;,
      &quot;value&quot;: &quot;${fuel}&quot;
    },
    {
      &quot;name&quot;: &quot;fuelstr&quot;,
      &quot;value&quot;: &quot;${fuelStr}&quot;
    },
    {
      &quot;name&quot;: &quot;engineType&quot;,
      &quot;value&quot;: &quot;${engineType}&quot;
    },
    {
      &quot;name&quot;: &quot;transmission&quot;,
      &quot;value&quot;: &quot;${transmission}&quot;
    },
    {
      &quot;name&quot;: &quot;gear&quot;,
      &quot;value&quot;: &quot;${gear}&quot;
    },
    {
      &quot;name&quot;: &quot;sitting&quot;,
      &quot;value&quot;: &quot;${sitting}&quot;
    },
    {
      &quot;name&quot;: &quot;cc&quot;,
      &quot;value&quot;: &quot;${cc}&quot;
    },
    {
      &quot;name&quot;: &quot;pPricelistStatus&quot;,
      &quot;value&quot;: &quot;${pricelistStatus}&quot;
    },
    {
      &quot;name&quot;: &quot;brandDesc&quot;,
      &quot;value&quot;: &quot;${brandDesc}&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${authorization}</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>0</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/VehicleMaintenance/saveSerie</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>0</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
