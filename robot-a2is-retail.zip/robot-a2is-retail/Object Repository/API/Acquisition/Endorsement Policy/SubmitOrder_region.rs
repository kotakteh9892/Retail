<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>SubmitOrder_region</name>
   <tag></tag>
   <elementGuidId>8d1b8298-70b3-4cd1-8800-b8d4c3f66c16</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;pPolicy&quot;,
      &quot;value&quot;: &quot;{\&quot;EndorsementPolicyDetail\&quot;:{\&quot;EffectiveDate\&quot;:\&quot;${getDate}\&quot;,\&quot;EndorsementType\&quot;:\&quot;${endorsType}\&quot;,\&quot;Remarks\&quot;:\&quot;${remark}\&quot;,\&quot;Items\&quot;:[\&quot;REGION\&quot;]},\&quot;PolicyInfo\&quot;:{\&quot;WTOrderID\&quot;:${WTOrderID},\&quot;PolicyNo\&quot;:\&quot;${policyNO}\&quot;,\&quot;OldPolicyNo\&quot;:\&quot;                \&quot;,\&quot;PolicyId\&quot;:\&quot;000017660960\&quot;,\&quot;OldOrderNo\&quot;:\&quot;${oldorderNo}\&quot;,\&quot;OrderNo\&quot;:\&quot;${orderNO}\&quot;,\&quot;QuotationNo\&quot;:\&quot;${quoationNo}\&quot;,\&quot;CustID\&quot;:\&quot;49978285\&quot;,\&quot;CustName\&quot;:\&quot;TOYOTA ASTRA FINANCE, PT (DENPASAR)\&quot;,\&quot;CustType\&quot;:\&quot;2\&quot;,\&quot;PolicyHolderCode\&quot;:\&quot;160973152\&quot;,\&quot;PolicyHolderName\&quot;:\&quot;NI LUH NGERTI SARI\&quot;,\&quot;PolicyHolderType\&quot;:\&quot;1\&quot;,\&quot;NameOnPolicy\&quot;:\&quot;PT. TOYOTA ASTRA FINANCIAL SERVICES QQ NI LUH NGERTI SARI\&quot;,\&quot;ProductCode\&quot;:\&quot;${GlobalVariable.productCode}\&quot;,\&quot;ProductDescription\&quot;:\&quot;TAGON - Product New Garda Oto TAFS New Car\&quot;,\&quot;MOUNumber\&quot;:\&quot;\&quot;,\&quot;ProductType\&quot;:1,\&quot;IsLexus\&quot;:0,\&quot;SegmentCode\&quot;:\&quot;P1G000\&quot;,\&quot;SegmentDesc\&quot;:\&quot;P1G000 - Toyota Astra Financial Services (TAFS)\&quot;,\&quot;AcceptanceType\&quot;:\&quot;DIRECT\&quot;,\&quot;AcceptanceTypeDesc\&quot;:\&quot;DIRECT\&quot;,\&quot;PeriodFrom\&quot;:\&quot;${periodFrom}\&quot;,\&quot;PeriodTo\&quot;:\&quot;${periodTo}\&quot;,\&quot;FinancialInstitutionID\&quot;:\&quot;49978285\&quot;,\&quot;FinancialInstitutionName\&quot;:\&quot;TOYOTA ASTRA FINANCE, PT (DENPASAR)\&quot;,\&quot;TermOfPaymentCode\&quot;:\&quot;TUNAI \&quot;,\&quot;RequestDuplicate\&quot;:false,\&quot;SalesmanID\&quot;:\&quot;TA014\&quot;,\&quot;SalesmanName\&quot;:\&quot;TAFS - DENPASAR\&quot;,\&quot;BranchID\&quot;:\&quot;014\&quot;,\&quot;BranchName\&quot;:\&quot;Denpasar\&quot;,\&quot;BranchAddress\&quot;:\&quot;Jl. Teuku Umar No. 80 Denpasar\&quot;,\&quot;BranchPostalCode\&quot;:\&quot;80113\&quot;,\&quot;BranchPostalCodeDesc\&quot;:\&quot;80113 - KEL. DAUH PURI KAUH, DENPASAR, BALI, INDONESIA\&quot;,\&quot;IsTitanProduct\&quot;:false,\&quot;AgentName\&quot;:null,\&quot;AgentCode\&quot;:null,\&quot;AgentUplinerName\&quot;:null,\&quot;AgentUplinerCode\&quot;:null,\&quot;AgentLeaderName\&quot;:null,\&quot;AgentLeaderCode\&quot;:null,\&quot;IsSalesmanDealer\&quot;:false,\&quot;SalesmanDealer\&quot;:null,\&quot;SalesmanDealerCode\&quot;:null,\&quot;Dealer\&quot;:null,\&quot;DealerCode\&quot;:null,\&quot;IsSalesmanDealerSameday\&quot;:false,\&quot;DealerBrokerSalesmanDealer\&quot;:null,\&quot;DealerBrokerSalesmanDealerCode\&quot;:null,\&quot;PolicyAddressTypeCode\&quot;:\&quot;POLADR\&quot;,\&quot;PolicyAddressSourceType\&quot;:\&quot;\&quot;,\&quot;PolicyAddressDeliveryCode\&quot;:\&quot;\&quot;,\&quot;PolicyAddressDesc\&quot;:\&quot;ULUN SIWI GG BUNTU SARI NO 2 A LINGK TEBE, Kelurahan JIMBARAN, Kecamatan KUTA SELATAN\&quot;,\&quot;PolicyAddressPostalCode\&quot;:\&quot;80364\&quot;,\&quot;PolicyAddressPostalCodeDesc\&quot;:\&quot;80364 - Jimbaran, Ungansan, DENPASAR, BALI, INDONESIA\&quot;,\&quot;PolicyAddressPhone\&quot;:\&quot;1234567890123456\&quot;,\&quot;PolicyAddressFax\&quot;:\&quot;\&quot;,\&quot;PolicyAddressHandphone\&quot;:\&quot;\&quot;,\&quot;PolicyAddressContactPerson\&quot;:\&quot;TOYOTA ASTRA FINANCE, PT (DENPASAR)\&quot;,\&quot;PolicyAddressRT\&quot;:\&quot;\&quot;,\&quot;PolicyAddressRW\&quot;:\&quot;\&quot;,\&quot;DeliveryAddressTypeCode\&quot;:\&quot;DELIVR\&quot;,\&quot;DeliveryAddressToType\&quot;:\&quot;OH\&quot;,\&quot;DeliveryAddressSourceType\&quot;:\&quot;CH\&quot;,\&quot;DeliveryAddressDeliveryCode\&quot;:\&quot;OH\&quot;,\&quot;DeliveryAddressDesc\&quot;:\&quot;jl.kotabaru\&quot;,\&quot;DeliveryAddressPostalCode\&quot;:\&quot;17133\&quot;,\&quot;DeliveryAddressPostalCodeDesc\&quot;:\&quot;17133 - KEL. MARGAHAYU, BEKASI, JAWA BARAT, INDONESIA\&quot;,\&quot;DeliveryAddressPhone\&quot;:\&quot;1234567890123456\&quot;,\&quot;DeliveryAddressFax\&quot;:\&quot;\&quot;,\&quot;DeliveryAddressHandphone\&quot;:\&quot;\&quot;,\&quot;DeliveryAddressContactPerson\&quot;:\&quot;\&quot;,\&quot;DeliveryAddressRT\&quot;:\&quot;\&quot;,\&quot;DeliveryAddressRW\&quot;:\&quot;\&quot;,\&quot;PayerCode\&quot;:\&quot;49978285\&quot;,\&quot;PayerName\&quot;:\&quot;TOYOTA ASTRA FINANCE, PT (DENPASAR)\&quot;,\&quot;BillingAddressTypeCode\&quot;:\&quot;BILADR\&quot;,\&quot;BillingAddressSourceType\&quot;:\&quot;OH\&quot;,\&quot;BillingAddressDeliveryCode\&quot;:\&quot;\&quot;,\&quot;BillingAddressDesc\&quot;:\&quot;asdasd\&quot;,\&quot;BillingAddressPostalCode\&quot;:\&quot;17133\&quot;,\&quot;BillingAddressPostalCodeDesc\&quot;:\&quot;17133 - KEL. MARGAHAYU, BEKASI, JAWA BARAT, INDONESIA\&quot;,\&quot;BillingAddressPhone\&quot;:\&quot;1234567890123456\&quot;,\&quot;BillingAddressFax\&quot;:\&quot;\&quot;,\&quot;BillingAddressHandphone\&quot;:\&quot;\&quot;,\&quot;BillingAddressContactPerson\&quot;:\&quot;\&quot;,\&quot;BillingAddressRT\&quot;:\&quot;\&quot;,\&quot;BillingAddressRW\&quot;:\&quot;\&quot;,\&quot;OurSharePercentage\&quot;:100,\&quot;SharePercentage\&quot;:100,\&quot;COBId\&quot;:\&quot;403\&quot;,\&quot;VANumber\&quot;:null,\&quot;GracePeriod\&quot;:\&quot;30\&quot;,\&quot;MOUID\&quot;:\&quot;\&quot;,\&quot;BrokerCode\&quot;:\&quot;\&quot;,\&quot;BrokerName\&quot;:null,\&quot;BaseCurrencyMinimumPremium\&quot;:\&quot;0.0000\&quot;,\&quot;StockMaximumPossible\&quot;:\&quot;100.000000\&quot;,\&quot;StockRefundLimit\&quot;:\&quot;100.000000\&quot;,\&quot;DayCalculationMethod\&quot;:\&quot;365\&quot;,\&quot;Timestamp\&quot;:\&quot;\&quot;,\&quot;Discount\&quot;:[],\&quot;Clause\&quot;:[],\&quot;Commission\&quot;:[{\&quot;MouID\&quot;:\&quot;TAGON           \&quot;,\&quot;ApplyFlags\&quot;:4095,\&quot;PayToParty\&quot;:\&quot;1\&quot;,\&quot;CommissionID\&quot;:\&quot;CM0009\&quot;,\&quot;IndividualTax\&quot;:0,\&quot;CorporateTax\&quot;:0,\&quot;CommissionLevel\&quot;:1,\&quot;CommissionType\&quot;:2,\&quot;CoverageID\&quot;:\&quot;      \&quot;,\&quot;CommissionName\&quot;:\&quot;Commission\&quot;,\&quot;Percentage\&quot;:25,\&quot;AppliedPercentage\&quot;:0,\&quot;CommissionFlags\&quot;:2}],\&quot;LongDiscount\&quot;:[],\&quot;Reinsurance\&quot;:{\&quot;PolicyID\&quot;:null,\&quot;AcceptanceType\&quot;:null,\&quot;Ceding\&quot;:null,\&quot;OfferingLetterDate\&quot;:null,\&quot;OfferingLetterNo\&quot;:null,\&quot;HandlingFeePct\&quot;:0,\&quot;WPCDate\&quot;:null,\&quot;OurShare\&quot;:0,\&quot;FullReceived\&quot;:false,\&quot;ReinsuranceMember\&quot;:[],\&quot;OrderNo\&quot;:\&quot;1210214673\&quot;},\&quot;IsApplyDiscount\&quot;:true,\&quot;EmailDeliverToType\&quot;:\&quot;PE\&quot;,\&quot;EmailDeliverToDesc\&quot;:\&quot;cad2testing@gmail.com\&quot;,\&quot;IsNeedHardCopy\&quot;:1}}&quot;
    },
    {
      &quot;name&quot;: &quot;pNSA&quot;,
      &quot;value&quot;: &quot;{\&quot;NSAItems\&quot;:[]}&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${GlobalVariable.authorization}</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/EndorsementPolicy/SubmitOrder</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
