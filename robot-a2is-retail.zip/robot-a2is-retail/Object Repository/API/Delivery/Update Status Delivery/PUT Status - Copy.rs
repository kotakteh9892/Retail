<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>PUT Status - Copy</name>
   <tag></tag>
   <elementGuidId>5f0cdfc8-ec03-40b8-aedb-1ec4d820f7f6</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>0</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;pDocNo&quot;,
      &quot;value&quot;: &quot;19080000090  &quot;
    },
    {
      &quot;name&quot;: &quot;pRefNo&quot;,
      &quot;value&quot;: &quot;1900614405-0&quot;
    },
    {
      &quot;name&quot;: &quot;pNameOnPolicy&quot;,
      &quot;value&quot;: &quot;SULAIMAN&quot;
    },
    {
      &quot;name&quot;: &quot;pStatusDelivery&quot;,
      &quot;value&quot;: &quot;OTW&quot;
    },
    {
      &quot;name&quot;: &quot;pReceivedDate&quot;,
      &quot;value&quot;: &quot;17/02/2021&quot;
    },
    {
      &quot;name&quot;: &quot;pReceiverName&quot;,
      &quot;value&quot;: &quot;ere&quot;
    },
    {
      &quot;name&quot;: &quot;pStatusReceiver&quot;,
      &quot;value&quot;: &quot;Ready&quot;
    },
    {
      &quot;name&quot;: &quot;pReason&quot;,
      &quot;value&quot;: &quot;Okay&quot;
    },
    {
      &quot;name&quot;: &quot;pUser&quot;,
      &quot;value&quot;: &quot;SKM&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Cookie</name>
      <type>Main</type>
      <value>EGRUM_BTM=053e1031-be29-4896-b377-043ee4ac7d02#~#1||0; TS0125c461=015294299a845bc1fd5dba23e6715534bf665fe683648b1c64f37198762e8e2f0574687bb02577e8b59b8000a86f8332c455f13753431c52dd3f56191e2f91824e8504a300</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer WBPQbsZiwOJg0BRsS4AhmUg7tTKYKzW9CRlU/eR2u79dIAM4g5xKfK82UpHrbsCoKwn/Qlp//UPeHdIoPz9mJQMqlA5pZlPzYEUjGxx2fdjCag+iMI9P8tlTVUCycJL49PvcE04W3qTv9kRPflfg1OF0w1wW18cIhEcoaut/lrsJQ4HKoQNqq/+6BcLiJy52AmTBH3pV02kjZll8KCybN5HvLq1NPYWj+LDj4jLYDakvI8ZnkhuoHdoQsf1PqVmX</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>0</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/UpdateStatusDelivery/PutDelivery</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>0</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>e0ba70bb-60d5-4044-b40b-9edbcbbe5b64</id>
      <masked>false</masked>
      <name>username</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>2a5c20c6-1eca-448e-bacf-34328784be1d</id>
      <masked>false</masked>
      <name>password</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
