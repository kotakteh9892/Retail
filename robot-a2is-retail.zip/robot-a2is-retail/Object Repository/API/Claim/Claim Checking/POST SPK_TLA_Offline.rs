<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>POST SPK_TLA_Offline</name>
   <tag></tag>
   <elementGuidId>9efbcffc-ea3c-45bb-9cc6-fd12b2b8d2d5</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;ReceptionID&quot;,
      &quot;value&quot;: &quot;${Idreception}&quot;
    },
    {
      &quot;name&quot;: &quot;DocumentCategory&quot;,
      &quot;value&quot;: &quot;${Dcategory}&quot;
    },
    {
      &quot;name&quot;: &quot;panel&quot;,
      &quot;value&quot;: &quot;${Panel}&quot;
    },
    {
      &quot;name&quot;: &quot;Approval&quot;,
      &quot;value&quot;: &quot;${Tapprove}&quot;
    },
    {
      &quot;name&quot;: &quot;ApprovalLimit&quot;,
      &quot;value&quot;: &quot;${Alimit}&quot;
    },
    {
      &quot;name&quot;: &quot;StampDuty&quot;,
      &quot;value&quot;: &quot;0&quot;
    },
    {
      &quot;name&quot;: &quot;Remarks&quot;,
      &quot;value&quot;: &quot;Ini Remarks&quot;
    },
    {
      &quot;name&quot;: &quot;AdjustmentF&quot;,
      &quot;value&quot;: &quot;${Adjust}&quot;
    },
    {
      &quot;name&quot;: &quot;UserRole&quot;,
      &quot;value&quot;: &quot;${Urole}&quot;
    },
    {
      &quot;name&quot;: &quot;isDocOnline&quot;,
      &quot;value&quot;: &quot;${Isonl}&quot;
    },
    {
      &quot;name&quot;: &quot;isB2B&quot;,
      &quot;value&quot;: &quot;${Isb2b}&quot;
    },
    {
      &quot;name&quot;: &quot;adjustableNett&quot;,
      &quot;value&quot;: &quot;${Anett}&quot;
    },
    {
      &quot;name&quot;: &quot;adjustableGross&quot;,
      &quot;value&quot;: &quot;${Agross}&quot;
    },
    {
      &quot;name&quot;: &quot;sendBackReason&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;sendBackRemarks&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;isApprove&quot;,
      &quot;value&quot;: &quot;0&quot;
    },
    {
      &quot;name&quot;: &quot;isUnSettled&quot;,
      &quot;value&quot;: &quot;0&quot;
    },
    {
      &quot;name&quot;: &quot;isSKET&quot;,
      &quot;value&quot;: &quot;false&quot;
    },
    {
      &quot;name&quot;: &quot;SPKTEMP&quot;,
      &quot;value&quot;: &quot;${Spktemp}&quot;
    },
    {
      &quot;name&quot;: &quot;TaxAmtTemp&quot;,
      &quot;value&quot;: &quot;${Taxtemp}&quot;
    },
    {
      &quot;name&quot;: &quot;partMaps&quot;,
      &quot;value&quot;: &quot;${Pmaps}&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${authorization}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Cookie</name>
      <type>Main</type>
      <value>zarget_visitor_info=%7B%7D; _ga=GA1.2.461465713.1608287569; _fbp=fb.1.1608287570152.1384352690; EGRUM_BTM=9e08df51-6182-472c-b03d-ae725092f54f#~#1||0; TS0125c461=015294299a09d8def86940a76655d6bc155227c243c46d8a316a1827c4bf21eea19ea19844ebf181abca001540a547e915a4735d9b1b473a1d0ae268d7e06535317da473fc</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/ClaimChecker/save_panel_total_loss_offline</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
