<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>GET Data Banjir</name>
   <tag></tag>
   <elementGuidId>7777a477-28f2-4ff6-9ab6-7dc7f24a0a16</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;pPageNo&quot;,
      &quot;value&quot;: &quot;1&quot;
    },
    {
      &quot;name&quot;: &quot;pPageAmount&quot;,
      &quot;value&quot;: &quot;20&quot;
    },
    {
      &quot;name&quot;: &quot;pSortOption&quot;,
      &quot;value&quot;: &quot;-1&quot;
    },
    {
      &quot;name&quot;: &quot;pSortDirection&quot;,
      &quot;value&quot;: &quot;12&quot;
    },
    {
      &quot;name&quot;: &quot;pFilterBy&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pFilterValue&quot;,
      &quot;value&quot;: &quot;&quot;
    },
    {
      &quot;name&quot;: &quot;pSearchBy&quot;,
      &quot;value&quot;: &quot;${Sby}&quot;
    },
    {
      &quot;name&quot;: &quot;pSearchValue&quot;,
      &quot;value&quot;: &quot;${Svalue}&quot;
    },
    {
      &quot;name&quot;: &quot;pDashboardType&quot;,
      &quot;value&quot;: &quot;${Dtype}&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${authorization}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Cookie</name>
      <type>Main</type>
      <value>zarget_visitor_info=%7B%7D; _ga=GA1.2.461465713.1608287569; _fbp=fb.1.1608287570152.1384352690; EGRUM_BTM=9e08df51-6182-472c-b03d-ae725092f54f#~#1||0; TS0125c461=015294299a09d8def86940a76655d6bc155227c243c46d8a316a1827c4bf21eea19ea19844ebf181abca001540a547e915a4735d9b1b473a1d0ae268d7e06535317da473fc</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/DashboardBanjir/GetSearchDashboardBanjir</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
