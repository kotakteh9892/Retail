<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>saveWreckBuyer</name>
   <tag></tag>
   <elementGuidId>2aac11a5-924e-4dae-89da-08e818ee4ed3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;pNameBuyer&quot;,
      &quot;value&quot;: &quot;${nameBuyer}&quot;
    },
    {
      &quot;name&quot;: &quot;pCPBuyer&quot;,
      &quot;value&quot;: &quot;${contactPersonBuyer}&quot;
    },
    {
      &quot;name&quot;: &quot;pAddressBuyer&quot;,
      &quot;value&quot;: &quot;${addressBuyer}&quot;
    },
    {
      &quot;name&quot;: &quot;pEmailBuyer&quot;,
      &quot;value&quot;: &quot;${emailBuyer}&quot;
    },
    {
      &quot;name&quot;: &quot;pBranchBuyer&quot;,
      &quot;value&quot;: &quot;${branchBuyer}&quot;
    },
    {
      &quot;name&quot;: &quot;pWorkshopBuyer&quot;,
      &quot;value&quot;: &quot;${workshopBuyer}&quot;
    },
    {
      &quot;name&quot;: &quot;pStatusBuyer&quot;,
      &quot;value&quot;: &quot;${statusBuyer}&quot;
    },
    {
      &quot;name&quot;: &quot;pType&quot;,
      &quot;value&quot;: &quot;${type}&quot;
    },
    {
      &quot;name&quot;: &quot;pWreckBuyerID&quot;,
      &quot;value&quot;: &quot;${wreckBuyerID}&quot;
    },
    {
      &quot;name&quot;: &quot;pGlobalImageID&quot;,
      &quot;value&quot;: &quot;${globalImageID}&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${authorization}</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/MaintenanceWreckBuyer/SaveWreckBuyer</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
