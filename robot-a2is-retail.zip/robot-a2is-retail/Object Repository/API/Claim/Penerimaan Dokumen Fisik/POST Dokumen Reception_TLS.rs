<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>POST Dokumen Reception_TLS</name>
   <tag></tag>
   <elementGuidId>11c9719f-fc8b-4c24-a674-896826158b63</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;contentType&quot;: &quot;application/x-www-form-urlencoded&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;,
  &quot;parameters&quot;: [
    {
      &quot;name&quot;: &quot;pListSpkNo&quot;,
      &quot;value&quot;: &quot;${Nspk}&quot;
    },
    {
      &quot;name&quot;: &quot;pMasterSpkNo&quot;,
      &quot;value&quot;: &quot;${Mspk)&quot;
    },
    {
      &quot;name&quot;: &quot;pSubmitType&quot;,
      &quot;value&quot;: &quot;${Stype}&quot;
    },
    {
      &quot;name&quot;: &quot;pDocumentData&quot;,
      &quot;value&quot;: &quot;${Ddata}&quot;
    },
    {
      &quot;name&quot;: &quot;pReceiptDate&quot;,
      &quot;value&quot;: &quot;2020-12-26&quot;
    },
    {
      &quot;name&quot;: &quot;pNomorKuitansi&quot;,
      &quot;value&quot;: &quot;212&quot;
    },
    {
      &quot;name&quot;: &quot;pNilaiKuitansi&quot;,
      &quot;value&quot;: &quot;21&quot;
    },
    {
      &quot;name&quot;: &quot;pNoStnk&quot;,
      &quot;value&quot;: &quot;1232&quot;
    },
    {
      &quot;name&quot;: &quot;pMasaBerlakuPajak&quot;,
      &quot;value&quot;: &quot;2020-12-26&quot;
    },
    {
      &quot;name&quot;: &quot;pNamaBpkb&quot;,
      &quot;value&quot;: &quot;asdsa&quot;
    },
    {
      &quot;name&quot;: &quot;pBahanBakar&quot;,
      &quot;value&quot;: &quot;asds&quot;
    },
    {
      &quot;name&quot;: &quot;pWarnaTnkb&quot;,
      &quot;value&quot;: &quot;qwewq&quot;
    },
    {
      &quot;name&quot;: &quot;pRemarks&quot;,
      &quot;value&quot;: &quot;231q&quot;
    },
    {
      &quot;name&quot;: &quot;pClaimType&quot;,
      &quot;value&quot;: &quot;${Ctype}&quot;
    }
  ]
}</httpBodyContent>
   <httpBodyType>x-www-form-urlencoded</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${authorization}</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/x-www-form-urlencoded</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Cookie</name>
      <type>Main</type>
      <value>zarget_visitor_info=%7B%7D; _ga=GA1.2.461465713.1608287569; _fbp=fb.1.1608287570152.1384352690; EGRUM_BTM=d3c1a53c-414d-4f4b-9921-ba0c800b353d#~#1||0; TS0125c461=015294299a82e2a90454559a257a9e1e499de0c965006b6c3502cbfcd74b028487074770ccc9ba7b4595266c1b270436b90e6f74a9db35d7a3b2a210d4cd023fd71620621b</value>
   </httpHeaderProperties>
   <katalonVersion>7.8.1</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://gen5-qc.asuransiastra.com/retail/API/PhysicalDocReception/SavePhysicalDocReception</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>5931cdd3-9d84-46f2-a3bd-95f28a526638</id>
      <masked>false</masked>
      <name>Nspk</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>7803a9cf-a092-461d-95c7-ecb30b23f64f</id>
      <masked>false</masked>
      <name>Mspk</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
