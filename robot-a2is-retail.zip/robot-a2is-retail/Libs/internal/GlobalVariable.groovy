package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object authorization
     
    /**
     * <p></p>
     */
    public static Object parameterLink
     
    /**
     * <p></p>
     */
    public static Object user
     
    /**
     * <p></p>
     */
    public static Object userDOC
     
    /**
     * <p></p>
     */
    public static Object userAAG
     
    /**
     * <p></p>
     */
    public static Object userJSW
     
    /**
     * <p></p>
     */
    public static Object userAPG
     
    /**
     * <p></p>
     */
    public static Object userTDL
     
    /**
     * <p></p>
     */
    public static Object userATP
     
    /**
     * <p></p>
     */
    public static Object userEDN
     
    /**
     * <p></p>
     */
    public static Object userEUW
     
    /**
     * <p></p>
     */
    public static Object pass
     
    /**
     * <p></p>
     */
    public static Object error
     
    /**
     * <p></p>
     */
    public static Object remarkID
     
    /**
     * <p></p>
     */
    public static Object orderNO
     
    /**
     * <p></p>
     */
    public static Object policyNO
     
    /**
     * <p></p>
     */
    public static Object mail
     
    /**
     * <p></p>
     */
    public static Object policyID
     
    /**
     * <p></p>
     */
    public static Object branchID
     
    /**
     * <p></p>
     */
    public static Object UID
     
    /**
     * <p>Profile sachi : submodul on call survey</p>
     */
    public static Object VehicleCode
     
    /**
     * <p></p>
     */
    public static Object PropertyId
     
    /**
     * <p></p>
     */
    public static Object PropertyDesc
     
    /**
     * <p></p>
     */
    public static Object WorkingTypeDesc
     
    /**
     * <p></p>
     */
    public static Object ChargeType
     
    /**
     * <p></p>
     */
    public static Object PropertyDetailId
     
    /**
     * <p></p>
     */
    public static Object PropertyDetailDesc
     
    /**
     * <p></p>
     */
    public static Object Qty
     
    /**
     * <p></p>
     */
    public static Object refNo
     
    /**
     * <p></p>
     */
    public static Object imageID
     
    /**
     * <p></p>
     */
    public static Object SPK
     
    /**
     * <p></p>
     */
    public static Object prefSPK
     
    /**
     * <p></p>
     */
    public static Object outstanding
     
    /**
     * <p></p>
     */
    public static Object category
     
    /**
     * <p></p>
     */
    public static Object detail
     
    /**
     * <p></p>
     */
    public static Object fraud
     
    /**
     * <p></p>
     */
    public static Object panelID
     
    /**
     * <p></p>
     */
    public static Object ID
     
    /**
     * <p></p>
     */
    public static Object surveyorID
     
    /**
     * <p></p>
     */
    public static Object sticker1
     
    /**
     * <p></p>
     */
    public static Object sticker2
     
    /**
     * <p></p>
     */
    public static Object sticker3
     
    /**
     * <p></p>
     */
    public static Object Name
     
    /**
     * <p></p>
     */
    public static Object var
     
    /**
     * <p></p>
     */
    public static Object surveyorIDto
     
    /**
     * <p></p>
     */
    public static Object remark1
     
    /**
     * <p></p>
     */
    public static Object remark2
     
    /**
     * <p></p>
     */
    public static Object remark3
     
    /**
     * <p></p>
     */
    public static Object status
     
    /**
     * <p></p>
     */
    public static Object descRemark
     
    /**
     * <p></p>
     */
    public static Object totalPanel
     
    /**
     * <p></p>
     */
    public static Object claimProperty
     
    /**
     * <p></p>
     */
    public static Object temp
     
    /**
     * <p></p>
     */
    public static Object list
     
    /**
     * <p></p>
     */
    public static Object dateFrom
     
    /**
     * <p></p>
     */
    public static Object dateTo
     
    /**
     * <p></p>
     */
    public static Object productCode
     
    /**
     * <p></p>
     */
    public static Object orderID
     
    /**
     * <p></p>
     */
    public static Object chasisNo
     
    /**
     * <p></p>
     */
    public static Object engineNo
     
    /**
     * <p></p>
     */
    public static Object oldorderNo
     
    /**
     * <p></p>
     */
    public static Object TermOfpay
     
    /**
     * <p></p>
     */
    public static Object gracePeriod
     
    /**
     * <p></p>
     */
    public static Object fee
     
    /**
     * <p></p>
     */
    public static Object HBhistory
     
    /**
     * <p></p>
     */
    public static Object GShistory
     
    /**
     * <p></p>
     */
    public static Object regisNO
     
    /**
     * <p></p>
     */
    public static Object phoneNO
     
    /**
     * <p></p>
     */
    public static Object src
     
    /**
     * <p></p>
     */
    public static Object year
     
    /**
     * <p></p>
     */
    public static Object retail
     
    /**
     * <p></p>
     */
    public static Object token
     
    /**
     * <p></p>
     */
    public static Object Cookie
     
    /**
     * <p></p>
     */
    public static Object password
     
    /**
     * <p>Profile sachi : Universal</p>
     */
    public static Object strPassword
     
    /**
     * <p></p>
     */
    public static Object SalesmanID
     
    /**
     * <p></p>
     */
    public static Object brandID
     
    /**
     * <p></p>
     */
    public static Object modelID
     
    /**
     * <p></p>
     */
    public static Object vehicleCode
     
    /**
     * <p></p>
     */
    public static Object orderNo
     
    /**
     * <p></p>
     */
    public static Object transactionNo
     
    /**
     * <p></p>
     */
    public static Object transactionType
     
    /**
     * <p></p>
     */
    public static Object roleID
     
    /**
     * <p></p>
     */
    public static Object approvalType
     
    /**
     * <p></p>
     */
    public static Object approvalValue
     
    /**
     * <p></p>
     */
    public static Object nextOrderStatus
     
    /**
     * <p></p>
     */
    public static Object policyNo
     
    /**
     * <p></p>
     */
    public static Object endorsementNo
     
    /**
     * <p></p>
     */
    public static Object SPK_number
     
    /**
     * <p></p>
     */
    public static Object wreckDetailAdjustmentRequestID
     
    /**
     * <p></p>
     */
    public static Object wreckDetailAdjustmentRequestDetailID
     
    /**
     * <p></p>
     */
    public static Object wreckListID
     
    /**
     * <p></p>
     */
    public static Object workshopName
     
    /**
     * <p></p>
     */
    public static Object locationID
     
    /**
     * <p></p>
     */
    public static Object locationDescription
     
    /**
     * <p></p>
     */
    public static Object wreckAuctionPeriodID
     
    /**
     * <p></p>
     */
    public static Object wreckBuyerID
     
    /**
     * <p></p>
     */
    public static Object panelCategoryID
     
    /**
     * <p></p>
     */
    public static Object wreckAuctionID
     
    /**
     * <p></p>
     */
    public static Object tasklistID
     
    /**
     * <p></p>
     */
    public static Object globalImageID
     
    /**
     * <p></p>
     */
    public static Object branchName
     
    /**
     * <p></p>
     */
    public static Object workshopID
     
    /**
     * <p></p>
     */
    public static Object wreckBuyerNameEdit
     
    /**
     * <p></p>
     */
    public static Object outReferenceNo
     
    /**
     * <p></p>
     */
    public static Object outTempOrderNoIsValid
     
    /**
     * <p></p>
     */
    public static Object refundPremium
     
    /**
     * <p></p>
     */
    public static Object effectiveDate
     
    /**
     * <p></p>
     */
    public static Object prospectID
     
    /**
     * <p></p>
     */
    public static Object quotationNo
     
    /**
     * <p></p>
     */
    public static Object WTOrderID
     
    /**
     * <p></p>
     */
    public static Object price
     
    /**
     * <p></p>
     */
    public static Object bodyGetAABCodeGeo
     
    /**
     * <p></p>
     */
    public static Object bodyGetVehiclePrice
     
    /**
     * <p></p>
     */
    public static Object bodyGetVehicleYear
     
    /**
     * <p></p>
     */
    public static Object bodyGetVehicle
     
    /**
     * <p></p>
     */
    public static Object bodyWTOrderDetail
     
    /**
     * <p></p>
     */
    public static Object email
     
    /**
     * <p></p>
     */
    public static Object bodyGetProdDetail
     
    /**
     * <p></p>
     */
    public static Object bodyGetProdDiscCom
     
    /**
     * <p></p>
     */
    public static Object bodyRecalKendaraan
     
    /**
     * <p></p>
     */
    public static Object premiumKendaraan
     
    /**
     * <p></p>
     */
    public static Object bodyRecalAcc
     
    /**
     * <p></p>
     */
    public static Object bodyGetAccDetailCat
     
    /**
     * <p></p>
     */
    public static Object bodyRecalDriver
     
    /**
     * <p></p>
     */
    public static Object premiumDriver
     
    /**
     * <p></p>
     */
    public static Object bodyRecalPass
     
    /**
     * <p></p>
     */
    public static Object premiumPass
     
    /**
     * <p></p>
     */
    public static Object premiumTJH
     
    /**
     * <p></p>
     */
    public static Object bodyRecalTJH
     
    /**
     * <p></p>
     */
    public static Object premiumAcc
     
    /**
     * <p></p>
     */
    public static Object totalPremium
     
    /**
     * <p></p>
     */
    public static Object kendaraanParse
     
    /**
     * <p></p>
     */
    public static Object accParse
     
    /**
     * <p></p>
     */
    public static Object policyBody
     
    /**
     * <p></p>
     */
    public static Object VAnumber
     
    /**
     * <p></p>
     */
    public static Object productCodeLexus
     
    /**
     * <p></p>
     */
    public static Object productCodeCashdealer
     
    /**
     * <p></p>
     */
    public static Object productCodeProkus
     
    /**
     * <p></p>
     */
    public static Object productCodeTI
     
    /**
     * <p></p>
     */
    public static Object productCodeTitanSyariah
     
    /**
     * <p></p>
     */
    public static Object productCodeGO
     
    /**
     * <p></p>
     */
    public static Object productCodeIEP
     
    /**
     * <p></p>
     */
    public static Object productCodeWIC
     
    /**
     * <p></p>
     */
    public static Object productCode2W
     
    /**
     * <p></p>
     */
    public static Object checkDiscount
     
    /**
     * <p></p>
     */
    public static Object checkCommission
     
    /**
     * <p></p>
     */
    public static Object checkLongDiscount
     
    /**
     * <p></p>
     */
    public static Object bodyCustomerProspect
     
    /**
     * <p></p>
     */
    public static Object bodyPolicyFee
     
    /**
     * <p></p>
     */
    public static Object bodyProspectCorporate
     
    /**
     * <p></p>
     */
    public static Object bodyProspectPersonal
     
    /**
     * <p></p>
     */
    public static Object SalesmanName
     
    /**
     * <p></p>
     */
    public static Object BranchID
     
    /**
     * <p></p>
     */
    public static Object productCodeRelaksasi
     
    /**
     * <p></p>
     */
    public static Object ProductCode
     
    /**
     * <p></p>
     */
    public static Object SegmentCode
     
    /**
     * <p></p>
     */
    public static Object EndorsementNo
     
    /**
     * <p></p>
     */
    public static Object globalParam1
     
    /**
     * <p></p>
     */
    public static Object ItemData
     
    /**
     * <p></p>
     */
    public static Object loopAgain
     
    /**
     * <p>Profile sachi : Universal</p>
     */
    public static Object strUsername
     
    /**
     * <p>Profile sachi : Nomor spk</p>
     */
    public static Object Nspk
     
    /**
     * <p></p>
     */
    public static Object Mspk
     
    /**
     * <p></p>
     */
    public static Object keyword_printspk
     
    /**
     * <p>Profile sachi : Nomor polis</p>
     */
    public static Object Npolicy
     
    /**
     * <p></p>
     */
    public static Object Code_checker
     
    /**
     * <p></p>
     */
    public static Object Status_checker
     
    /**
     * <p></p>
     */
    public static Object Name_group
     
    /**
     * <p></p>
     */
    public static Object Status_group
     
    /**
     * <p>Profile sachi : submodul maintenance target loading</p>
     */
    public static Object Id_loadmap
     
    /**
     * <p>Profile sachi : submodul maintenance target loading</p>
     */
    public static Object Id_loadmap_class
     
    /**
     * <p>Profile sachi : submodul approval spk ar</p>
     */
    public static Object Nsurvey
     
    /**
     * <p>Profile sachi : sumodul tasklist add spk, dasboard banjir</p>
     */
    public static Object Nrequest
     
    /**
     * <p>Profile sachi : Nama Bengkel - submodul claim checking</p>
     */
    public static Object Name_workshop
     
    /**
     * <p>Profile sachi : submodul claim checking</p>
     */
    public static Object Id_workshop
     
    /**
     * <p>Profile sachi : submodul claim checking, print spc</p>
     */
    public static Object Id_reception
     
    /**
     * <p>Profile sachi : Estimation,Final,Invoice ReceptionID- submodul claim checking</p>
     */
    public static Object Doc_rcpt
     
    /**
     * <p>Profile sachi : Status dokumen - submodul claim checking</p>
     */
    public static Object Status_doc
     
    /**
     * <p>Profile sachi : No Claim - submodul claim checking</p>
     */
    public static Object Nclaim
     
    /**
     * <p>Profile sachi : submodul mapping coord, report status survey</p>
     */
    public static Object CoordinatorCode
     
    /**
     * <p>Profile sachi : submodul mapping coord</p>
     */
    public static Object CoordinatorName
     
    /**
     * <p>Profile sachi : submodul mapping coord</p>
     */
    public static Object CoordinatorPIC
     
    /**
     * <p>Profile sachi : submodul mapping coord</p>
     */
    public static Object CoordinatorPICName
     
    /**
     * <p>Profile sachi : submodul mapping branch, survey area</p>
     */
    public static Object AreaCode
     
    /**
     * <p>Profile sachi : submodul mapping branch</p>
     */
    public static Object AliasName
     
    /**
     * <p>Profile sachi : submodul print spc</p>
     */
    public static Object TotalEstimation
     
    /**
     * <p>Profile sachi : submodul print spc</p>
     */
    public static Object SumInsured
     
    /**
     * <p>Profile sachi : submodul print spc</p>
     */
    public static Object AgreedValue
     
    /**
     * <p>Profile sachi : submodul print spc</p>
     */
    public static Object PayTo
     
    /**
     * <p>Profile sachi : submodul print spc</p>
     */
    public static Object PayToAdrress
     
    /**
     * <p>Profile sachi : submodul transfer surveyor</p>
     */
    public static Object Sparam
     
    /**
     * <p>Profile sachi : submodul transfer surveyor</p>
     */
    public static Object CodeHistory
     
    /**
     * <p>Profile sachi : submodul dashboard banjir</p>
     */
    public static Object UIDBanjir
     
    /**
     * <p>Profile sachi : No LK - submodul dashboard banjir</p>
     */
    public static Object Nlk
     
    /**
     * <p>Profile sachi : modul delivery</p>
     */
    public static Object NoReference
     
    /**
     * <p>Profile sachi : modul delivery</p>
     */
    public static Object IdDocument
     
    /**
     * <p>Profile sachi : modul delivery</p>
     */
    public static Object Address
     
    /**
     * <p>Profile sachi : modul delivery</p>
     */
    public static Object PostalCode
     
    /**
     * <p>Profile sachi : modul delivery</p>
     */
    public static Object PolicyName
     
    /**
     * <p>Profile sachi : modul delivery</p>
     */
    public static Object MobileNumber
     
    /**
     * <p>Profile sachi : modul delivery</p>
     */
    public static Object TypeDelivery
     
    /**
     * <p>Profile sachi : modul delivery</p>
     */
    public static Object NoDelivery
     
    /**
     * <p>Profile sachi : modul delivery</p>
     */
    public static Object NoGroup
     
    /**
     * <p>Profile sachi : submodul survey schedule</p>
     */
    public static Object FileID
     
    /**
     * <p>Profile sachi : submodul survey area</p>
     */
    public static Object AreaName
     
    /**
     * <p>Profile sachi : submodul survey area</p>
     */
    public static Object AliasArea
     
    /**
     * <p>Profile sachi : submodul survey area</p>
     */
    public static Object Idbranch
     
    /**
     * <p>Profile sachi : submodul send document</p>
     */
    public static Object Role
     
    /**
     * <p>Profile sachi : submodul send document</p>
     */
    public static Object CourierName
     
    /**
     * <p>Profile sachi : submodul delivery list</p>
     */
    public static Object TypeDocument
     
    /**
     * <p>Profile sachi : submodul on call survey</p>
     */
    public static Object NoOrder
     
    /**
     * <p>Profile sachi : submodul on call survey</p>
     */
    public static Object IdCustomer
     
    /**
     * <p></p>
     */
    public static Object Flag
     
    /**
     * <p></p>
     */
    public static Object VehicleDescription
     
    /**
     * <p></p>
     */
    public static Object NoChassis
     
    /**
     * <p></p>
     */
    public static Object NoEngine
     
    /**
     * <p></p>
     */
    public static Object AreaDescription
     
    /**
     * <p></p>
     */
    public static Object SurveyAreaCode
     
    /**
     * <p>Profile sachi : submodul report status survey</p>
     */
    public static Object DateFrom
     
    /**
     * <p>Profile sachi : submodul report status survey</p>
     */
    public static Object DateTo
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            authorization = selectedVariables['authorization']
            parameterLink = selectedVariables['parameterLink']
            user = selectedVariables['user']
            userDOC = selectedVariables['userDOC']
            userAAG = selectedVariables['userAAG']
            userJSW = selectedVariables['userJSW']
            userAPG = selectedVariables['userAPG']
            userTDL = selectedVariables['userTDL']
            userATP = selectedVariables['userATP']
            userEDN = selectedVariables['userEDN']
            userEUW = selectedVariables['userEUW']
            pass = selectedVariables['pass']
            error = selectedVariables['error']
            remarkID = selectedVariables['remarkID']
            orderNO = selectedVariables['orderNO']
            policyNO = selectedVariables['policyNO']
            mail = selectedVariables['mail']
            policyID = selectedVariables['policyID']
            branchID = selectedVariables['branchID']
            UID = selectedVariables['UID']
            VehicleCode = selectedVariables['VehicleCode']
            PropertyId = selectedVariables['PropertyId']
            PropertyDesc = selectedVariables['PropertyDesc']
            WorkingTypeDesc = selectedVariables['WorkingTypeDesc']
            ChargeType = selectedVariables['ChargeType']
            PropertyDetailId = selectedVariables['PropertyDetailId']
            PropertyDetailDesc = selectedVariables['PropertyDetailDesc']
            Qty = selectedVariables['Qty']
            refNo = selectedVariables['refNo']
            imageID = selectedVariables['imageID']
            SPK = selectedVariables['SPK']
            prefSPK = selectedVariables['prefSPK']
            outstanding = selectedVariables['outstanding']
            category = selectedVariables['category']
            detail = selectedVariables['detail']
            fraud = selectedVariables['fraud']
            panelID = selectedVariables['panelID']
            ID = selectedVariables['ID']
            surveyorID = selectedVariables['surveyorID']
            sticker1 = selectedVariables['sticker1']
            sticker2 = selectedVariables['sticker2']
            sticker3 = selectedVariables['sticker3']
            Name = selectedVariables['Name']
            var = selectedVariables['var']
            surveyorIDto = selectedVariables['surveyorIDto']
            remark1 = selectedVariables['remark1']
            remark2 = selectedVariables['remark2']
            remark3 = selectedVariables['remark3']
            status = selectedVariables['status']
            descRemark = selectedVariables['descRemark']
            totalPanel = selectedVariables['totalPanel']
            claimProperty = selectedVariables['claimProperty']
            temp = selectedVariables['temp']
            list = selectedVariables['list']
            dateFrom = selectedVariables['dateFrom']
            dateTo = selectedVariables['dateTo']
            productCode = selectedVariables['productCode']
            orderID = selectedVariables['orderID']
            chasisNo = selectedVariables['chasisNo']
            engineNo = selectedVariables['engineNo']
            oldorderNo = selectedVariables['oldorderNo']
            TermOfpay = selectedVariables['TermOfpay']
            gracePeriod = selectedVariables['gracePeriod']
            fee = selectedVariables['fee']
            HBhistory = selectedVariables['HBhistory']
            GShistory = selectedVariables['GShistory']
            regisNO = selectedVariables['regisNO']
            phoneNO = selectedVariables['phoneNO']
            src = selectedVariables['src']
            year = selectedVariables['year']
            retail = selectedVariables['retail']
            token = selectedVariables['token']
            Cookie = selectedVariables['Cookie']
            password = selectedVariables['password']
            strPassword = selectedVariables['strPassword']
            SalesmanID = selectedVariables['SalesmanID']
            brandID = selectedVariables['brandID']
            modelID = selectedVariables['modelID']
            vehicleCode = selectedVariables['vehicleCode']
            orderNo = selectedVariables['orderNo']
            transactionNo = selectedVariables['transactionNo']
            transactionType = selectedVariables['transactionType']
            roleID = selectedVariables['roleID']
            approvalType = selectedVariables['approvalType']
            approvalValue = selectedVariables['approvalValue']
            nextOrderStatus = selectedVariables['nextOrderStatus']
            policyNo = selectedVariables['policyNo']
            endorsementNo = selectedVariables['endorsementNo']
            SPK_number = selectedVariables['SPK_number']
            wreckDetailAdjustmentRequestID = selectedVariables['wreckDetailAdjustmentRequestID']
            wreckDetailAdjustmentRequestDetailID = selectedVariables['wreckDetailAdjustmentRequestDetailID']
            wreckListID = selectedVariables['wreckListID']
            workshopName = selectedVariables['workshopName']
            locationID = selectedVariables['locationID']
            locationDescription = selectedVariables['locationDescription']
            wreckAuctionPeriodID = selectedVariables['wreckAuctionPeriodID']
            wreckBuyerID = selectedVariables['wreckBuyerID']
            panelCategoryID = selectedVariables['panelCategoryID']
            wreckAuctionID = selectedVariables['wreckAuctionID']
            tasklistID = selectedVariables['tasklistID']
            globalImageID = selectedVariables['globalImageID']
            branchName = selectedVariables['branchName']
            workshopID = selectedVariables['workshopID']
            wreckBuyerNameEdit = selectedVariables['wreckBuyerNameEdit']
            outReferenceNo = selectedVariables['outReferenceNo']
            outTempOrderNoIsValid = selectedVariables['outTempOrderNoIsValid']
            refundPremium = selectedVariables['refundPremium']
            effectiveDate = selectedVariables['effectiveDate']
            prospectID = selectedVariables['prospectID']
            quotationNo = selectedVariables['quotationNo']
            WTOrderID = selectedVariables['WTOrderID']
            price = selectedVariables['price']
            bodyGetAABCodeGeo = selectedVariables['bodyGetAABCodeGeo']
            bodyGetVehiclePrice = selectedVariables['bodyGetVehiclePrice']
            bodyGetVehicleYear = selectedVariables['bodyGetVehicleYear']
            bodyGetVehicle = selectedVariables['bodyGetVehicle']
            bodyWTOrderDetail = selectedVariables['bodyWTOrderDetail']
            email = selectedVariables['email']
            bodyGetProdDetail = selectedVariables['bodyGetProdDetail']
            bodyGetProdDiscCom = selectedVariables['bodyGetProdDiscCom']
            bodyRecalKendaraan = selectedVariables['bodyRecalKendaraan']
            premiumKendaraan = selectedVariables['premiumKendaraan']
            bodyRecalAcc = selectedVariables['bodyRecalAcc']
            bodyGetAccDetailCat = selectedVariables['bodyGetAccDetailCat']
            bodyRecalDriver = selectedVariables['bodyRecalDriver']
            premiumDriver = selectedVariables['premiumDriver']
            bodyRecalPass = selectedVariables['bodyRecalPass']
            premiumPass = selectedVariables['premiumPass']
            premiumTJH = selectedVariables['premiumTJH']
            bodyRecalTJH = selectedVariables['bodyRecalTJH']
            premiumAcc = selectedVariables['premiumAcc']
            totalPremium = selectedVariables['totalPremium']
            kendaraanParse = selectedVariables['kendaraanParse']
            accParse = selectedVariables['accParse']
            policyBody = selectedVariables['policyBody']
            VAnumber = selectedVariables['VAnumber']
            productCodeLexus = selectedVariables['productCodeLexus']
            productCodeCashdealer = selectedVariables['productCodeCashdealer']
            productCodeProkus = selectedVariables['productCodeProkus']
            productCodeTI = selectedVariables['productCodeTI']
            productCodeTitanSyariah = selectedVariables['productCodeTitanSyariah']
            productCodeGO = selectedVariables['productCodeGO']
            productCodeIEP = selectedVariables['productCodeIEP']
            productCodeWIC = selectedVariables['productCodeWIC']
            productCode2W = selectedVariables['productCode2W']
            checkDiscount = selectedVariables['checkDiscount']
            checkCommission = selectedVariables['checkCommission']
            checkLongDiscount = selectedVariables['checkLongDiscount']
            bodyCustomerProspect = selectedVariables['bodyCustomerProspect']
            bodyPolicyFee = selectedVariables['bodyPolicyFee']
            bodyProspectCorporate = selectedVariables['bodyProspectCorporate']
            bodyProspectPersonal = selectedVariables['bodyProspectPersonal']
            SalesmanName = selectedVariables['SalesmanName']
            BranchID = selectedVariables['BranchID']
            productCodeRelaksasi = selectedVariables['productCodeRelaksasi']
            ProductCode = selectedVariables['ProductCode']
            SegmentCode = selectedVariables['SegmentCode']
            EndorsementNo = selectedVariables['EndorsementNo']
            globalParam1 = selectedVariables['globalParam1']
            ItemData = selectedVariables['ItemData']
            loopAgain = selectedVariables['loopAgain']
            strUsername = selectedVariables['strUsername']
            Nspk = selectedVariables['Nspk']
            Mspk = selectedVariables['Mspk']
            keyword_printspk = selectedVariables['keyword_printspk']
            Npolicy = selectedVariables['Npolicy']
            Code_checker = selectedVariables['Code_checker']
            Status_checker = selectedVariables['Status_checker']
            Name_group = selectedVariables['Name_group']
            Status_group = selectedVariables['Status_group']
            Id_loadmap = selectedVariables['Id_loadmap']
            Id_loadmap_class = selectedVariables['Id_loadmap_class']
            Nsurvey = selectedVariables['Nsurvey']
            Nrequest = selectedVariables['Nrequest']
            Name_workshop = selectedVariables['Name_workshop']
            Id_workshop = selectedVariables['Id_workshop']
            Id_reception = selectedVariables['Id_reception']
            Doc_rcpt = selectedVariables['Doc_rcpt']
            Status_doc = selectedVariables['Status_doc']
            Nclaim = selectedVariables['Nclaim']
            CoordinatorCode = selectedVariables['CoordinatorCode']
            CoordinatorName = selectedVariables['CoordinatorName']
            CoordinatorPIC = selectedVariables['CoordinatorPIC']
            CoordinatorPICName = selectedVariables['CoordinatorPICName']
            AreaCode = selectedVariables['AreaCode']
            AliasName = selectedVariables['AliasName']
            TotalEstimation = selectedVariables['TotalEstimation']
            SumInsured = selectedVariables['SumInsured']
            AgreedValue = selectedVariables['AgreedValue']
            PayTo = selectedVariables['PayTo']
            PayToAdrress = selectedVariables['PayToAdrress']
            Sparam = selectedVariables['Sparam']
            CodeHistory = selectedVariables['CodeHistory']
            UIDBanjir = selectedVariables['UIDBanjir']
            Nlk = selectedVariables['Nlk']
            NoReference = selectedVariables['NoReference']
            IdDocument = selectedVariables['IdDocument']
            Address = selectedVariables['Address']
            PostalCode = selectedVariables['PostalCode']
            PolicyName = selectedVariables['PolicyName']
            MobileNumber = selectedVariables['MobileNumber']
            TypeDelivery = selectedVariables['TypeDelivery']
            NoDelivery = selectedVariables['NoDelivery']
            NoGroup = selectedVariables['NoGroup']
            FileID = selectedVariables['FileID']
            AreaName = selectedVariables['AreaName']
            AliasArea = selectedVariables['AliasArea']
            Idbranch = selectedVariables['Idbranch']
            Role = selectedVariables['Role']
            CourierName = selectedVariables['CourierName']
            TypeDocument = selectedVariables['TypeDocument']
            NoOrder = selectedVariables['NoOrder']
            IdCustomer = selectedVariables['IdCustomer']
            Flag = selectedVariables['Flag']
            VehicleDescription = selectedVariables['VehicleDescription']
            NoChassis = selectedVariables['NoChassis']
            NoEngine = selectedVariables['NoEngine']
            AreaDescription = selectedVariables['AreaDescription']
            SurveyAreaCode = selectedVariables['SurveyAreaCode']
            DateFrom = selectedVariables['DateFrom']
            DateTo = selectedVariables['DateTo']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
